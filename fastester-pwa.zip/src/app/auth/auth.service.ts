import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _userIsAUthendicated = false;

  get userIsAuthendicated() {
    return this._userIsAUthendicated;
  }
 
  constructor() { }

  login(){
    this._userIsAUthendicated = true;
  }

  logout(){
    this._userIsAUthendicated = false;
  }
}
