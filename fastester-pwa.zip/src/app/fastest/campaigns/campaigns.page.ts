import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { PreRequisitesComponent } from '../../campaigns/pre-requisites/pre-requisites.component';

@Component({
  selector: 'app-campaigns',
  templateUrl: './campaigns.page.html',
  styleUrls: ['./campaigns.page.scss'],
})
export class CampaignsPage implements OnInit {

  constructor(
    private modal: ModalController,
  ) { }

  ngOnInit() {
  }

  nominate() {
    this.modal.create({
      component: PreRequisitesComponent,
      componentProps: {test: 'Testing'}
    }).then( modalEl => {
      modalEl.present();
    })
  }

}
