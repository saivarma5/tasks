import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { CampaignsPage } from './campaigns.page';
import { PreRequisitesComponent } from '../../campaigns/pre-requisites/pre-requisites.component';

const routes: Routes = [
  {
    path: '',
    component: CampaignsPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [CampaignsPage, PreRequisitesComponent],
  entryComponents: [PreRequisitesComponent]
})
export class CampaignsPageModule {}
