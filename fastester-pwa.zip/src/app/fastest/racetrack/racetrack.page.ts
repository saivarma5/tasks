import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-racetrack',
  templateUrl: './racetrack.page.html',
  styleUrls: ['./racetrack.page.scss'],
})
export class RacetrackPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
