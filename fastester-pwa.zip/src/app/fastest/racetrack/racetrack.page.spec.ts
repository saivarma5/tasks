import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RacetrackPage } from './racetrack.page';

describe('RacetrackPage', () => {
  let component: RacetrackPage;
  let fixture: ComponentFixture<RacetrackPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RacetrackPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RacetrackPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
