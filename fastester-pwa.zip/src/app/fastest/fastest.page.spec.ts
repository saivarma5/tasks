import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FastestPage } from './fastest.page';

describe('FastestPage', () => {
  let component: FastestPage;
  let fixture: ComponentFixture<FastestPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FastestPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FastestPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
