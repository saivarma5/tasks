import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fastest',
  templateUrl: './fastest.page.html',
  styleUrls: ['./fastest.page.scss'],
})
export class FastestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
