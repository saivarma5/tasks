import { NgModule } from '@angular/core';
import { RouterModule,  Routes } from '@angular/router';
import { FastestPage } from './fastest.page';


const routes: Routes = [
    {
        path: 'tabs',
        component: FastestPage,
        children: [
            {
                path: 'campaigns', 
                children: [
                    {
                        path: '',
                        loadChildren: './campaigns/campaigns.module#CampaignsPageModule'
                    }
                ]
            },
            {
                path: 'racetrack', children: [
                    {
                        path: '',
                        loadChildren: './racetrack/racetrack.module#RacetrackPageModule'
                    }
                ]
            },
            {
                path: 'redeem', children: [
                    {
                        path: '',
                        loadChildren: './redeem/redeem.module#RedeemPageModule'
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/fastest/tabs/campaigns',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/fastest/tabs/campaigns',
        pathMatch: 'full'
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class FastestRoutingModule{

}