import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promoter',
  templateUrl: './promoter.page.html',
  styleUrls: ['./promoter.page.scss'],
})
export class PromoterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
