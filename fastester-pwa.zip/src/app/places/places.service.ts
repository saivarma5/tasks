import { Injectable } from '@angular/core';
import { Place } from './place.model';

@Injectable({
  providedIn: 'root'
})
export class PlacesService {

  private _places: Place[] = [
    new Place(
      'p1',
      'Manhattan Mansion',
      'In the heart of New York city',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Above_Gotham.jpg/488px-Above_Gotham.jpg',
      149.99
    ),
    new Place(
      'p2',
      'L\'Amour Toujours',
      'A romantaic place in Parris',
      'https://lh3.googleusercontent.com/proxy/JYNkwHzySR4pF5wfZxdm9VFZcIhQqBXg1NQBgOmFh8raerI8UKjyr6_cLDwwYRThAEw5tLNlH_Ura0qceDcH0gy6gCrR60MjLze4f3NVccOOR2XKEa49Zk00dTynVUqtrmJYJS23TmC4edothbdDsllVXjc=w125-h168-n-k-no',
      189.99
    ),
    new Place(
      'p3',
      'The Foggy Palace',
      'Not your average city trip!',
      'https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Schwerin_Palace_Park_Garden_Mecklenburg_Germany_Schweriner_Schloss_Garten_BUGA_2009.jpg/330px-Schwerin_Palace_Park_Garden_Mecklenburg_Germany_Schweriner_Schloss_Garten_BUGA_2009.jpg',
      99.99
    ),

  ];

  get places(){
    return [...this._places]; 
  }

  constructor() { }

  getPlace(id: string){
    return {...this._places.find(p => p.id === id)};
  }
}
